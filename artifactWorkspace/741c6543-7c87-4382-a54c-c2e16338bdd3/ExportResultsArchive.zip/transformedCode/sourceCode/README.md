# eShopOnBlazor

> eShop sample applications have been updated and moved to https://github.com/dotnet/eShop. Active development will continue there.

Migration of a traditional ASP.NET Web Forms app to Blazor.

## Read the Book

[Download the free PDF eBook, Blazor for ASP.NET Web Forms Developers](https://aka.ms/blazor-ebook) or [read the latest version online](https://learn.microsoft.com/dotnet/architecture/blazor-for-web-forms-developers/).

## Latest Version

This sample has been updated for .NET 8.
